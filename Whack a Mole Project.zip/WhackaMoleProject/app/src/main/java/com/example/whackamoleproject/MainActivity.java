package com.example.whackamoleproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    private static final long GAME_TIME = 60000;
    private static final long MOLE_INTERVAL = 1000;
    private ImageView d1, d2, d3, d4, d5, d6, d7, d8, d9;
    private TextView scoreTv, timerTv;
    private List<Integer> nonVisibleMolesList = new ArrayList<Integer>();

    private int[] moleIds = {
            R.id.firstIv,
            R.id.secondIv,
            R.id.thirdIv,
            R.id.fourthIv,
            R.id.fifthIv,
            R.id.sixthIv,
            R.id.seventhIv,
            R.id.eighthIv,
            R.id.ninthIv
    };

    //private CountDownTimer mCountDownTimer;
    private  Timer mTimer;
    private long mTimeLeft ;
    private AtomicBoolean isMoleVisible;
    private AtomicBoolean isPowerMoleVisible;
    private AtomicInteger mScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeViews();
        setOnClickListeners();
        disableClicks();
        initializeGame();
        animateCloud();

    }
    private void initializeGame() {
        updateScore(0);
        fillNonVisibleMolesList(0);
        mTimer = new Timer();
        mTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                mTimeLeft += 500;
                updateTimer(mTimeLeft);
                if(!isMoleVisible.get())
                    displayMole();
                if(mTimeLeft >= GAME_TIME){
                    mTimer.cancel();
                }
            }
        },0,500);
    }


    private void setOnClickListeners() {
        for(int id : moleIds){
            findViewById(id).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isMoleVisible.get()){
                        mScore.addAndGet(1);
                        updateScore(mScore.get());
                        if(isPowerMoleVisible.get()){
                           mTimeLeft = mTimeLeft - 3000;
                           updateTimer(mTimeLeft);
                        }
                    }
                }
            });

        }
    }

    private void updateScore(int mScore) {
        scoreTv.setText(getString(R.string.score_d,mScore));
        ScaleAnimation scaleAnimation = new ScaleAnimation(
                0.5f,1.0f, 0.5f,1.0f, Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f
        );
        scaleAnimation.setDuration(500);
        scoreTv.setAnimation(scaleAnimation);
        scoreTv.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_baseline_star_border_24,0,0,0);
        scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                scoreTv.setCompoundDrawablesWithIntrinsicBounds(0,0,0,0);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


        addStartsToLayout(mScore);
    }

    private void updateTimer(long timeLeft){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                long seconds = (GAME_TIME - timeLeft) / 1000;
                String timeString = String.valueOf(seconds);
                timerTv.setText(getString(R.string.time_left_s,timeString));
            }
        });
    }


    private void displayMole() {
        //Pic a random hole
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Random random = new Random();
                int randomId = nonVisibleMolesList.get(random.nextInt(nonVisibleMolesList.size()));
                ImageView randomHole =  findViewById(randomId);

                int powerNumber = random.nextInt(10);
                if(powerNumber > 6){
                    randomHole.setImageResource(R.drawable.hole_with_mole_power);
                    isPowerMoleVisible.set(true);
                }else{
                    randomHole.setImageResource(R.drawable.hole_with_mole);
                    isPowerMoleVisible.set(false);
                }
                isMoleVisible.set(true);
                randomHole.setEnabled(true);
                fillNonVisibleMolesList(randomId);


                randomHole.setAlpha(0.4f);
                randomHole.animate()
                        .setDuration(500)
                        .alpha(1f)
                        .setListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                            }
                        });




                Timer timer = new Timer();
                TimerTask timerTask = new TimerTask() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                randomHole.setImageResource(R.drawable.hole_without_mole);
                                randomHole.setEnabled(false);
                                isMoleVisible.set(false);
                                isPowerMoleVisible.set(false);

                                randomHole.animate()
                                        .alpha(1.0f)
                                        .setListener(new AnimatorListenerAdapter() {
                                            @Override
                                            public void onAnimationEnd(Animator animation) {
                                                super.onAnimationEnd(animation);
                                            }
                                        });

                            }
                        });
                        timer.cancel();
                    }
                };
                timer.schedule(timerTask,MOLE_INTERVAL);
            }
        });

    }

    private void disableClicks() {
        d1.setEnabled(false);
        d2.setEnabled(false);
        d3.setEnabled(false);
        d4.setEnabled(false);
        d5.setEnabled(false);
        d6.setEnabled(false);
        d7.setEnabled(false);
        d8.setEnabled(false);
        d9.setEnabled(false);
    }

    private void initializeViews() {
        d1 = findViewById(R.id.firstIv);
        d2 = findViewById(R.id.fourthIv);
        d3 = findViewById(R.id.secondIv);
        d4 = findViewById(R.id.thirdIv);
        d5 = findViewById(R.id.sixthIv);
        d6 = findViewById(R.id.seventhIv);
        d7 = findViewById(R.id.fifthIv);
        d8 = findViewById(R.id.eighthIv);
        d9 = findViewById(R.id.ninthIv);
        scoreTv = findViewById(R.id.scoreTv);
        timerTv = findViewById(R.id.timerTv);
        mScore = new AtomicInteger(0);
        isMoleVisible = new AtomicBoolean(false);
        isPowerMoleVisible = new AtomicBoolean(false);
    }

    private void fillNonVisibleMolesList(int visibleMoleId){
        nonVisibleMolesList.clear();
        for(int id : moleIds){
            if(id != visibleMoleId){
                nonVisibleMolesList.add(id);
            }
        }
    }

    private void addStartsToLayout(int score){
           if(score == 0)
               return;
            LinearLayout firstRowLL = findViewById(R.id.firstRowLL);
            LinearLayout secondRowLL = findViewById(R.id.secondRowLL);
            LinearLayout thirdRowLL = findViewById(R.id.thirdRowLL);
            ImageView imageView = new ImageView(this);
            imageView.setBackgroundResource(R.drawable.ic_baseline_star_border_24);
            if(score<14){
             firstRowLL.addView(imageView);
            }else if(score<24){
                secondRowLL.addView(imageView);
            }else {
                thirdRowLL.addView(imageView);
            }

    }

    private void animateCloud(){
        ImageView leftCloudImv = findViewById(R.id.cloudImgLeft);
        ImageView centerCloudImv = findViewById(R.id.cloudImgCenter);
        ImageView endCloudImv = findViewById(R.id.cloudImgEnd);


        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        //Screen width
        int width = displayMetrics.widthPixels;

        TranslateAnimation animateRight = new TranslateAnimation(width * -1, width,0f,0f);
        animateRight.setDuration(15000);
        animateRight.setRepeatCount(Integer.MAX_VALUE);
        animateRight.setRepeatMode(Animation.INFINITE);
        leftCloudImv.setAnimation(animateRight);
        centerCloudImv.setAnimation(animateRight);
        endCloudImv.setAnimation(animateRight);

    }

}